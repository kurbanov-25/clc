package com.example.xtr100.app1_diplomado_calc.tools;

import com.example.xtr100.app1_diplomado_calc.entities.Operation;

/**
 * Created by XTR100 on 19/07/2016.
 */
public interface AsyncFunctionResult {

    public void postProcess(String result);
}
